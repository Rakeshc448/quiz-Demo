# QuizApp

QuizApp is a simple quiz game in which there are 5 questions and this is a part of Android-Scholarship programme and user get score on the basis of how correct questions he has done.


## layout_main.xml

![quizapp](https://user-images.githubusercontent.com/25812257/37365881-cd524362-2724-11e8-9f83-727eed215b86.PNG)



![ds](https://user-images.githubusercontent.com/25812257/37366036-48e5b504-2725-11e8-9066-2823a0df35cc.PNG)
